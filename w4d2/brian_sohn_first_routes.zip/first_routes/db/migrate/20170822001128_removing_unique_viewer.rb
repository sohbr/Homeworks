class RemovingUniqueViewer < ActiveRecord::Migration[5.1]
  def change
    remove_index :artwork_shares, :viewer_id
    remove_index :artworks, :title
  end
end
